package modules;

import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Message {

	@SerializedName("sender")
    @Expose
	private String sender;
	
	@SerializedName("receiver")
    @Expose
	private String receiver;
	
	@SerializedName("text")
    @Expose
	private String text;
	
	@SerializedName("date")
	@Expose
	private LocalDateTime date;

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public String getSender() {
		return sender;
	}
	
	public String getReceiver() {
		return receiver;
	}
	
	public String getText() {
		return text;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public void setText(String text) {
		this.text = text;
	}
	
}