package modules;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import application.Main;
import controller.ChatController;
import javafx.stage.Stage;

public class Chat {

	public Gson gson = new GsonBuilder().registerTypeAdapter(LocalDateTime.class, new GsonLocalDateTimeAdapter())
			.registerTypeAdapter(LocalDate.class, new GsonLocalDateTimeAdapter()).create();

	public Stage stage;
	public ChatController control;

	// 클라이언트 중지

	public void send(Message message) {


		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				try {
					byte[] buffer = gson.toJson(message).getBytes("UTF-8");
					System.out.println("Buffer Size = "+buffer.length);
					Main.serverOs.write(buffer);
					Main.serverOs.flush();
				} catch (Exception e) {
					try {
						System.out.println("[메세지 송신 오류] : "
								+ Thread.currentThread().getName());
						e.printStackTrace();
					} catch (Exception e2) {
						System.out.println("Thread Exception! ");
						e2.printStackTrace();
					}
				}
			}

		};
		Main.threadPool.submit(runnable);
	}

	
	public void setStage(Stage s) {
		stage =s;
	}
	public Stage getStage() {
		return stage;
	}

	public ChatController getControl() {
		return control;
	}

	public void setControl(ChatController control) {
		this.control = control;
	}


}
