package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modules.Friend;
import modules.Member;

public class DataBase {
	
	private Connection conn = null;

	public DataBase() {
		System.out.println("DataBase Connenting....");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521";
			String user = "L";
			String pass = "lee";
			conn = DriverManager.getConnection(url, user, pass);
			System.out.print(" 연결완료 Connection 객체 생성완료!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public Member requestLogin(String id, String password) {
		Member member = null;
		try {
			Statement stmt = conn.createStatement();
			String sql = "SELECT * FROM MEMBER WHERE ID = '"+id+"' AND PASSWORD = '"+password+"'";
			ResultSet rs = stmt.executeQuery(sql);
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				member = new Member(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));				
			}else{
				System.out.println("[Login] id 와 password가 일치하는 사용자가 존재 하지 않습니다.");
				rs.close();
				stmt.close();
				return null;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return member;
	}
	
	public Friend requestFriend(String id) {
		try {
			Statement stmt = conn.createStatement();
			String sql = "SELECT friend_id FROM FRIEND where user_id = '"+id+"' order by friend_id asc";
			ResultSet rs = stmt.executeQuery(sql);
			ArrayList<String> friendList = new ArrayList<String>();
			while(rs.next()) {
				friendList.add(rs.getString(1));
			}
			Friend friend = new Friend();
			friend.setFriendList(friendList);
			rs.close();
			stmt.close();
			return friend;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void close() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
