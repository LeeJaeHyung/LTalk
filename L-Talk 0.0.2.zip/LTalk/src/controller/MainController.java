package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import application.LTalkServer;
import application.Main;
import application.SoundClient;
import application.SoundSender;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import modules.Chat;
import modules.Member;

public class MainController implements Initializable {

	static private Member member;
	static private Stage stage;
	static private Chat chat;

	@FXML
	BorderPane root;
	@FXML
	VBox root_Left_VBox;
	@FXML
	HBox root_center_HBox;
	@FXML
	Button closeb;
	@FXML
	Button hideb;
	@FXML
	Button friendButton;
	@FXML
	Button chatListButton;
	@FXML
	Text checkT;
	@FXML
	VBox changeFild;
	@FXML
	ImageView friendI;
	@FXML
	ImageView talkI;
	@FXML
	ScrollPane scrollPane;
	
	VBox friendFild;
	VBox chatFild;
	VBox showFild;

	ArrayList<String> openList;

	private double x = 0;
	private double y = 0;
	private boolean profile = false;// profile 필드에 마우스가 들어왔는지 체크
	private String nowView = "친구";

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		System.out.println(Thread.currentThread().getName() + " => [ListController] initialize() is Strating");
		closeb.setStyle("-fx-background-color:#FFFFFF");
		hideb.setStyle("-fx-background-color:#FFFFFF");
		root.setStyle("-fx-background-color:#FFFFFF");
		root_Left_VBox.setStyle("-fx-background-color:#ECECED; -fx-border-color:#ECECED");
		root_Left_VBox.setPadding(new Insets(35,0,50,0));
		chatListButton.setStyle("-fx-background-color:#ECECED;");
		chatListButton.setPadding(new Insets(10,15,10,15));
		friendButton.setStyle("-fx-background-color:#ECECED;");
		friendButton.setPadding(new Insets(10,15,10,15));
		hideb.setStyle("-fx-background-color:#FFFFFF");
		friendFild = new VBox();
		chatFild = new VBox();
		showFild = friendFild;
		changeFild.setMargin(checkT, new Insets(10));
		scrollPane.setHbarPolicy(ScrollBarPolicy.NEVER);
		checkT.setText(nowView);
		checkT.setStyle("-fx-font-size: 20px; -fx-font-family: 'Malgun Gothic';");
		
		closeb.setOnAction(event -> Platform.exit());// 처리방식 변경
		talkI.setOpacity(0.3);
		friendI.setOpacity(1);
		friendList();
		cahtList();
		stageMove();
		stageMove2();
//		maxWindow();
		hiddingButton();
//		resizeTrue();
		
		

	}
	
	private void cahtList() {
		int size = Main.member.getFriend().getFriendList().size();
		ObservableList children = chatFild.getChildren();
		for(int i = 0; i<size; i++) {
			HBox box = new HBox();
			VBox vBox = new VBox();
			Text text = new Text("이전 내용입니다");
			vBox.setAlignment(Pos.CENTER_LEFT);
			vBox.setSpacing(5);
			box.setUserData(Main.member.getFriend().getFriendList().get(i));
			box.setPrefWidth(289);
			box.setAlignment(Pos.CENTER_LEFT);
			box.setSpacing(8);
			Rectangle rec = new Rectangle(40,40);
			rec.setArcHeight(25);
			rec.setArcWidth(25);
			Image im = new Image("file:src/images/lee.png");
			rec.setFill(new ImagePattern(im));
			Label label = new Label(Main.member.getFriend().getFriendList().get(i));
			label.setStyle("-fx-background-color: transparent; -fx-font-family: 'Malgun Gothic Bold'; -fx-text-fill: #000000;");
//			label.setPrefSize(289, 100);
//			label.setOnMouseClicked(event ->{
//				Label target = (Label)event.getSource();
//				try {
//					openChat(target.getText());
//				} catch (Exception e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			});
//			label.setOnMouseEntered(event -> {
//				Label target = (Label)event.getSource();
//				target.getParent().setStyle("-fx-background-color:#F8F8F8");
//				target.setStyle("-fx-background-color:#F8F8F8");
//			});
//			label.setOnMouseExited(event -> {
//				Label target = (Label)event.getSource();
//				target.getParent().setStyle("-fx-background-color:#FFFFFF");
//				target.setStyle("-fx-background-color:#FFFFFF");
//			});
			rec.setCursor(Cursor.HAND);
			rec.setOnMouseClicked(event -> {
				System.out.println("프로필 클릭 데스요~");
			});
			
			rec.setOnMouseEntered(event-> {
				profile = true;
			});
			rec.setOnMouseExited(event -> {
				profile = false;
			});
			
			box.setOnMouseClicked(event -> {
				HBox target = (HBox)event.getSource();
				try {
					if(!profile) {
						openChat((String)target.getUserData());
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			box.setOnMouseEntered(event -> {
				HBox target = (HBox)event.getSource();
				target.setStyle("-fx-background-color:#F8F8F8");
			});
			box.setOnMouseExited(event -> {
				HBox target = (HBox)event.getSource();
				target.setStyle("-fx-background-color:#FFFFFF");
			});
			vBox.getChildren().addAll(label,text);
			box.getChildren().addAll(rec,vBox);
			box.setMargin(rec, new Insets(15,0,10,10));
			children.add(box);
		}
	}

	private void friendList() {

		int size = Main.member.getFriend().getFriendList().size();
		ObservableList children = friendFild.getChildren();
		for (int i = 0; i < size; i++) {
			HBox box = new HBox();
			VBox vBox = new VBox();
			vBox.setAlignment(Pos.CENTER_LEFT);
			vBox.setSpacing(5);
			box.setUserData(Main.member.getFriend().getFriendList().get(i));
			box.setPrefWidth(289);
			box.setAlignment(Pos.CENTER_LEFT);
			box.setSpacing(8);
			Rectangle rec = new Rectangle(40,40);
			rec.setArcHeight(25);
			rec.setArcWidth(25);
			Image im = new Image("file:src/images/lee.png");
			rec.setFill(new ImagePattern(im));
			Label label = new Label(Main.member.getFriend().getFriendList().get(i));
			label.setStyle("-fx-background-color: transparent; -fx-font-family: 'Malgun Gothic Bold'; -fx-text-fill: #000000;");
//			label.setPrefSize(289, 100);
//			label.setOnMouseClicked(event ->{
//				Label target = (Label)event.getSource();
//				try {
//					openChat(target.getText());
//				} catch (Exception e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			});
//			label.setOnMouseEntered(event -> {
//				Label target = (Label)event.getSource();
//				target.getParent().setStyle("-fx-background-color:#F8F8F8");
//				target.setStyle("-fx-background-color:#F8F8F8");
//			});
//			label.setOnMouseExited(event -> {
//				Label target = (Label)event.getSource();
//				target.getParent().setStyle("-fx-background-color:#FFFFFF");
//				target.setStyle("-fx-background-color:#FFFFFF");
//			});
			rec.setCursor(Cursor.HAND);
			rec.setOnMouseClicked(event -> {
				System.out.println("프로필 클릭 데스요~");
			});
			
			rec.setOnMouseEntered(event-> {
				profile = true;
			});
			rec.setOnMouseExited(event -> {
				profile = false;
			});
			
			box.setOnMouseClicked(event -> {
				HBox target = (HBox)event.getSource();
				try {
					if(!profile) {
						openChat((String)target.getUserData());
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			box.setOnMouseEntered(event -> {
				HBox target = (HBox)event.getSource();
				target.setStyle("-fx-background-color:#F8F8F8");
			});
			box.setOnMouseExited(event -> {
				HBox target = (HBox)event.getSource();
				target.setStyle("-fx-background-color:#FFFFFF");
			});
			vBox.getChildren().add(label);
			box.getChildren().addAll(rec,vBox);
			box.setMargin(rec, new Insets(15,0,10,10));
			children.add(box);
		}
		changeFild.getChildren().add(friendFild);
	}

	private void stageMove() {// https://ohtanja.tistory.com/90 참고함
		root_Left_VBox.setOnMousePressed((event) -> {
			x = event.getSceneX();
			y = event.getSceneY();
		});

		root_Left_VBox.setOnMouseDragged((event) -> {
			stage.setX(event.getScreenX() - x);
			stage.setY(event.getScreenY() - y);
		});

		root_Left_VBox.setOnMouseReleased((event) -> {
		});
	}

	private void stageMove2() {// https://ohtanja.tistory.com/90 참고함
		root_center_HBox.setOnMousePressed((event) -> {
			x = event.getSceneX();
			y = event.getSceneY();
		});

		root_center_HBox.setOnMouseDragged((event) -> {
			stage.setX(event.getScreenX() - x);
			stage.setY(event.getScreenY() - y);
		});

		root_center_HBox.setOnMouseReleased((event) -> {
		});
	}

	private void hiddingButton() {
		hideb.setOnAction(event -> {
			stage.setIconified(true);
			System.out.println(member.getId());
		});

	}

//	private void maxWindow() { //최대화
//		
//		maxb.setOnAction(event -> {
//			stage = (Stage) acp.getScene().getWindow();
//			stage.setMaximized(true);
//		});
//		
//	}

	public void changeFrame(ActionEvent e) {
		Button target = (Button) e.getSource();
		String data = target.getUserData().toString();
		System.out.println("[ListController] changeFrame() is started UserData: " + data);
		if (!nowView.equals(data)) {// 현제 표시된 화면과 같지 않을때
			switch (data) {
			case "friend":
				System.out.println("친구목록!");
				Platform.runLater(() -> {
					checkT.setText("친구");
					changeFild.getChildren().remove(showFild);
					changeFild.getChildren().add(friendFild);
					talkI.setOpacity(0.3);
					friendI.setOpacity(1);
					showFild = friendFild;
				});
				nowView = data;
				break;
			case "talk":
				System.out.println("채팅목록!");
				Platform.runLater(() -> {
					checkT.setText("채팅");
					changeFild.getChildren().remove(showFild);
					changeFild.getChildren().add(chatFild);
					talkI.setOpacity(1);
					friendI.setOpacity(0.3);
					showFild = chatFild;
				});
				nowView = data;
				break;
			}
		}
	}

	public void openChat(ActionEvent e) throws IOException {
		System.out.println("[ListController] openTestChat() is Started");
		Stage chatStage = new Stage();
		Parent chatParent;
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Chat.fxml"));
		chatParent = loader.load();
		ChatController chatController = loader.getController();
		chatController.setReceiver("lee");
		chatController.setSender("Tester");
		// chatParent = FXMLLoader.load(getClass().getResource("/view/Chat.fxml"));
		Scene chatScene = new Scene(chatParent);
		chatStage.setScene(chatScene);
		chatStage.setResizable(true);
		chatStage.getIcons().add(new Image("file:src/images/icon.png"));
		chatStage.setTitle("LTalk");
		chatStage.initStyle(StageStyle.UNDECORATED);
		chatStage.show();
		Runnable runnable = new Runnable() {
			public void run() {
				System.out.println("chat Start");
				chat.setStage(chatStage);
				chat.setControl(chatController);
				Main.chatList.put("Tester", chat);
			}
		};
		Main.threadPool.submit(runnable);
	}

	public void openChat(String receiver) throws Exception {
		System.out.println("[ListController] openTestChat() is Started");
		Stage chatStage = new Stage();
		Parent chatParent;
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Chat.fxml"));
		chatParent = loader.load();
		ChatController chatController = loader.getController();
		chatController.setReceiver(receiver);
		chatController.setSender(Main.member.getId());
		// chatParent = FXMLLoader.load(getClass().getResource("/view/Chat.fxml"));
		Scene chatScene = new Scene(chatParent);
		chatStage.setScene(chatScene);
		chatStage.setResizable(true);
		chatStage.getIcons().add(new Image("file:src/images/icon.png"));
		chatStage.setTitle("LTalk" + receiver);
		chatStage.initStyle(StageStyle.UNDECORATED);
		chatStage.show();
		chatController.setTarget(receiver);
		chatController.setStage(chatStage);
		Runnable runnable = new Runnable() {
			public void run() {
				System.out.println("chat Start");
				chat.setStage(chatStage);
				chat.setControl(chatController);
				Main.chatList.put(receiver, chat);
			}
		};
		Main.threadPool.submit(runnable);
	}

	public void openServer(ActionEvent e) throws IOException {
		System.out.println("[ListController] openServer() is Started");
		Stage serverStage = new Stage();
		serverStage.setUserData(stage.getUserData());
		new LTalkServer().start(serverStage);
	}

	public void openChatServer(ActionEvent e) {
		System.out.println("[ListController] openChatServer() is Started");

	}

	public void openVoiceChat(ActionEvent e) {
		System.out.println("[ListController] openVoiceChat() is Started");
		Thread scThread = new Thread(() -> {
			SoundClient.start();
		});

		System.out.println("[ListController] openVoiceChat() Create scThread");

		Thread ssThread = new Thread(() -> {
			SoundSender.start();
		});

		System.out.println("[ListController] openVoiceChat() Create ssThread");

		scThread.start();
		System.out.println("[ListController] openVoiceChat() in scThread.start() is Started");
		ssThread.start();
		System.out.println("[ListController] openVoiceChat() in ssThread.start() is Started");

	}

	public void openTestChat(ActionEvent e) throws IOException {

		String receiver;

		if (member.getId().equals("lee")) {
			receiver = "Tester";
		} else {
			receiver = "lee";
		}

		System.out.println("[ListController] openTestChat() is Started");
		Stage chatStage = new Stage();
		Parent chatParent;
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Chat.fxml"));
		chatParent = loader.load();
		ChatController chatController = loader.getController();
		chatController.setReceiver(receiver);
		chatController.setSender(member.getId());
		// chatParent = FXMLLoader.load(getClass().getResource("/view/Chat.fxml"));
		Scene chatScene = new Scene(chatParent);
		chatStage.setScene(chatScene);
		chatStage.setResizable(true);
		chatStage.getIcons().add(new Image("file:src/images/icon.png"));
		chatStage.setTitle("LTalk" + receiver);
		chatStage.initStyle(StageStyle.UNDECORATED);
		chatStage.show();
		chatController.setTarget(receiver);
		Runnable runnable = new Runnable() {
			public void run() {
				System.out.println("chat Start");
				chat.setStage(chatStage);
				chat.setControl(chatController);
				Main.chatList.put(receiver, chat);
			}
		};
		Main.threadPool.submit(runnable);
	}

	public static void setMember(Member m) {
		member = m;
	}

	public static Member getMember() {
		return member;
	}

	public static void setStage(Stage s) {
		stage = s;
	}

	public static Chat getChat() {
		return chat;
	}

	public static void setChat(Chat c) {
		chat = c;
	}

}
