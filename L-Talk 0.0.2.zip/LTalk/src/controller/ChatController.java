package controller;

import java.net.Socket;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.TextArea;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import modules.Member;
import modules.Message;

public class ChatController implements Initializable{
	
//	public static Map<String ,ChatController> controllerList = new HashMap<String ,ChatController>();
	@FXML
	BorderPane root;
	@FXML
	HBox root_center_HBox;
	@FXML
	VBox root_Center_VBox;
	@FXML
	Button closeb;
	@FXML
	Button hideb;
	@FXML
	Button sendButton;
	@FXML
	TextArea textArea;
//	@FXML
//	TextArea messageArea;
	@FXML
	VBox messageBox;
	@FXML
	ScrollPane scrollpane;
	@FXML
	Rectangle rectangle;
	@FXML
	Text receiverName;
	
	

	private Date lastDate;
	private String receiver;
	private String sender;
	Member member;
	Socket socket;
	private boolean last = false;
	private boolean buttonChange = false;

	boolean textAreaFocus = false;
	private static String serverIP = "127.0.0.1"; // 로컬 주소
	private static int serverPort = 7623;
	
	Stage stage = null;
	private double x = 0, y = 0;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			System.out.println(Thread.currentThread().getName()+" => [ChatController] initialize() is Strating");
			closeb.setStyle("-fx-background-color:#BACEE0");
			hideb.setStyle("-fx-background-color:#BACEE0");
			root_Center_VBox.setStyle("-fx-background-color:#BACEE0");
			root.setStyle("-fx-background-color:#BACEE0");
			// [현제 아래 버튼에 대한 이벤트 발생시 모든 프로그램이 종료됨 ] 해당 채팅방만 닫히는 기능구현이 필요함 
			closeb.setOnAction(event -> closeStage());
			sendButton.setStyle("-fx-background-color: #F0F0F0;-fx-text-fill: #DADADA;-fx-font-family: 'Malgun Gothic';");
			messageBox.setPadding(new Insets(5));
			scrollpane.setContent(messageBox);
			scrollpane.setHbarPolicy(ScrollBarPolicy.NEVER);
			scrollpane.setStyle("-fx-background: transparent; -fx-background-color: transparent; -fx-border-color:#BACEE0;");
			Image im = new Image("file:src/images/lee.png");
			rectangle.setFill(new ImagePattern(im));
			stageMove();
			hiddingButton();
			sendButtonOnAction();
			sendTextAreaOnkey();
			scrollEvent();
			//ChatStart();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
//	private void setStyle() {
//		System.out.println(getClass().getResource("/css/Chat.css").toString());
//		try{
//			
//			scene = root.getScene();
//			System.out.println(scene.toString());
////			System.out.println(root.getScene().toString());
////			scene.getStylesheets().add(getClass().getResource("/css/Chat.css").toString());
//		}catch(Exception e){
//			e.printStackTrace();
//			System.out.println("에러 발생");
//		}
//		
//	}
	
	/*
	 * 	1. 서버에 채팅하고자 하는 사용자가 있는지 확인 Yes || No
	 * 	  		Yes => 해당 사용자에게 데이터를 전송
	 *  		No  => Server에 있는 DB에 데이터를 저장
	 *  
	 */
//	private void ChatStart() {
//		
//		Thread chatThread = new Thread() {
//			public void run() {
//				try {
//					Socket soket = new Socket(IP,port);
//					
//					checkIn();
//					
//				}catch(Exception e) {
//					e.printStackTrace();
//				}
//			}
//		};
//	}
//	
//	private void checkIn(String userIP) {
//		
//	}
	
	public void setTarget(String userName) {
		Platform.runLater(()->{
			receiverName.setText(userName);
		});
	}
	
	
	
	private void scrollEvent() {
		scrollpane.needsLayoutProperty().addListener((observable, oldValue, newValue) -> {
		    if (!newValue) {
		        scrollpane.setVvalue(1.0);
		    }
		});
	}
	

	private void hiddingButton() {
		hideb.setOnAction(event -> {stage = (Stage) root.getScene().getWindow(); stage.setIconified(true);});
	}
	
	private void closeStage() {
		System.out.println("ChatController.closeStage() is Strat");
		try {
			stage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	private void stageMove() {//https://ohtanja.tistory.com/90 참고함
		root_center_HBox.setOnMousePressed((event) -> {
			x = event.getSceneX();
			y = event.getSceneY();
		});

		root_center_HBox.setOnMouseDragged((event) -> {
			stage = (Stage) root.getScene().getWindow();
			stage.setX(event.getScreenX() - x);
			stage.setY(event.getScreenY() - y);
		});

		root_center_HBox.setOnMouseReleased((event) -> {
			stage = (Stage) root.getScene().getWindow();
		});
	}
	
	
	public void sendTextAreaOnkey() {
		textArea.setOnKeyPressed((event) -> {
			if(event.getCode()==KeyCode.ENTER) {
				sendFunction();
			}
			
			if(textArea.getText().equals("")) {
				if(buttonChange) {
					buttonChange = false;
					sendButton.setStyle("-fx-background-color: #F0F0F0;-fx-text-fill: #DADADA;-fx-font-family: 'Malgun Gothic';");
				}
			}else if(!buttonChange) {
				//색상추가
				buttonChange = true;
				sendButton.setStyle("-fx-background-color: #FFEB33;-fx-text-fill: #000000;-fx-font-family: 'Malgun Gothic';");
		
			}
		});
	}
	
	
	
	//text 전달 메소드
	public void sendButtonOnAction() {
		sendButton.setOnAction((event) -> {
			if(buttonChange) {
				buttonChange = false;
				sendButton.setStyle("-fx-background-color: #F0F0F0;-fx-text-fill: #DADADA;-fx-font-family: 'Malgun Gothic';");
			}
			sendFunction();
		});
	}
	
	public void sendFunction() {
		String text = textArea.getText();
		if(text.equals("\n")||text.equals("")) {
			textArea.setText("");
			return;
		}
		System.out.println("[ChatController] in sendFucntion Text : "+text );
		Message message = new Message();
		message.setReceiver(receiver);
		message.setSender(sender);
		message.setText(text);
		MainController.getChat().send(message);
		textArea.setText("");
		sendMessage(message.getText());
		
	}
	
	public void moveScroll() {
		Platform.runLater(()-> {
			messageBox.layout();
			scrollpane.setVvalue(1.0d);
		});
	}
	
	public void receiveMessage(Message message) {
		System.out.println("receiveMessage() is success!");
		//messageArea.appendText(receiver+" : "+message);
		dateChecker();
		try {
			if(last){
				Platform.runLater(()->{
//					Label msg = new Label(message.getText());
//					msg.setStyle("-fx-background-color: #FFEB33");
//					HBox box = new HBox();
//					box.getChildren().add(msg);
//					box.setSpacing(8);
//					box.setAlignment(Pos.TOP_LEFT);
//					box.getChildren().addAll(msg);
//					messageBox.getChildren().add(box);
					HBox box = new HBox();
					Label msg = new Label(message.getText());
					msg.setStyle("-fx-background-color: #FFEB33");
					box.getChildren().addAll(msg);
					box.setAlignment(Pos.CENTER_LEFT);
					VBox.setMargin(box, new Insets(3.5));
					messageBox.getChildren().add(box);
					box.setMargin(msg, new Insets(0.0, 0.0, 0.0, 48.0));
//					scrollpane.vvalueProperty().bind(messageBox.heightProperty());
				});
			}else {
				Platform.runLater(()->{
					Text text = new Text(message.getSender());
					HBox box = new HBox();
					VBox chatBox = new VBox();
					chatBox.setSpacing(3.5);
					Rectangle rec = new Rectangle(40,40);
					rec.setArcHeight(25);
					rec.setArcWidth(25);
					Image im = new Image("file:src/images/lee.png");
					rec.setFill(new ImagePattern(im));
					box.setSpacing(8);
					Label msg = new Label(message.getText());
					box.setAlignment(Pos.TOP_LEFT);
					VBox.setMargin(box, new Insets(3.5));
					msg.setStyle("-fx-background-color: #FFEB33");
					chatBox.getChildren().addAll(text,msg);
					box.getChildren().addAll(rec,chatBox);
					messageBox.getChildren().add(box);
					last = true;
				});
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println(scrollpane.getVvalue());
	}
	
	public void sendMessage(String message) {
		System.out.println("sendMessage");
		dateChecker();
		try {
			Platform.runLater(()->{
				HBox box = new HBox();
				Label msg = new Label(message);
				box.getChildren().addAll(msg);
				box.setAlignment(Pos.CENTER_RIGHT);
				VBox.setMargin(box, new Insets(3.5));
				messageBox.getChildren().add(box);
			}); 
		}catch(Exception e) {
			e.printStackTrace();
		}
		last = false;
		
	}
	
	public void dateChecker() {
		if(!(lastDate == null)) {
			Date nowDate = new Date();
			if(compareDate(lastDate, nowDate)) {
				lastDate = nowDate;
				addPrintDate();			
			}
		}else {
			lastDate = new Date();
			addPrintDate();
		}
		
	}
	
	public void addPrintDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("  yyyy년 MM월 dd일 E요일  ");
		Platform.runLater(()->{
			VBox box = new VBox();
			Label dateT = new Label(sdf.format(lastDate));
			dateT.setStyle("-fx-background-color: #B1C3D5; -fx-background-radius: 15px; -fx-effect:  dropshadow(three-pass-box , rgba(167,185,201,0.7) , 1, 0 , 1, 1);");
			box.setAlignment(Pos.CENTER);
			box.getChildren().add(dateT);
			messageBox.getChildren().add(box);
		});
	}
	public boolean compareDate(Date beforD, Date newD) {
		//y -> m -> d 
		//y, m, d가 모두 같을경우 ->아무일도 일어 나지 않음
		if(beforD.getYear() == newD.getYear()) {
			if(beforD.getMonth() == newD.getMonth()) {
				if(beforD.getDay() < newD.getDay()) {
					return true;
				}
			}else if(beforD.getMonth() < newD.getMonth()) {
				return true;
			}
		}else if(beforD.getYear() < newD.getYear()) {
			return true;
		}
		
		return false;
		
	}


	public String getReceiver() {
		return receiver;
	}


	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}


	public String getSender() {
		return sender;
	}


	public void setSender(String sender) {
		this.sender = sender;
	}
	
	public void setStage(Stage stage) {
		this.stage = stage;
	}
	
}
