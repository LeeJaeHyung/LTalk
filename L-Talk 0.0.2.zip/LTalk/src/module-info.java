module LTalk {
	
	requires javafx.controls;
	requires javafx.base;
	requires javafx.graphics;
	requires javafx.media;
	requires javafx.fxml;
	requires java.sql;
	requires java.desktop;
	requires com.google.gson;
	
	opens application to controller, modules, javafx.graphics, javafx.fxml, javafx.controls, javafx.base, javafx.media, java.sql, com.google.gson;
	opens controller to application, modules, javafx.graphics, javafx.fxml, javafx.controls, javafx.base, javafx.media, java.sql, com.google.gson;
	opens modules to application, controller, javafx.graphics, javafx.fxml, javafx.controls, javafx.base, javafx.media, java.sql, com.google.gson;
}
