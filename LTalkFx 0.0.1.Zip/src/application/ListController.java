package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ListController implements Initializable{
	
	@FXML
	BorderPane root;
	@FXML
	VBox root_Left_VBox;
	@FXML
	HBox root_center_HBox;
	@FXML
	Button closeb;
	@FXML
	Button hideb;
	
	
	
	private double x = 0;
	private double y = 0;
	private Stage stage;
	private String nowView = "friend";

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		System.out.println(Thread.currentThread().getName()+" => [ListController] initialize() is Strating");
		closeb.setStyle("-fx-background-color:#FFFFFF");
		hideb.setStyle("-fx-background-color:#FFFFFF");
		root.setStyle("-fx-background-color:#FFFFFF");
		root_Left_VBox.setStyle("-fx-background-color:#ECECED");
		hideb.setStyle("-fx-background-color:#FFFFFF");
		closeb.setOnAction(event -> Platform.exit());
		stageMove();
		stageMove2();
//		maxWindow();
		hiddingButton();
//		resizeTrue();
		
		
	}
	
	private void stageMove() {//https://ohtanja.tistory.com/90 ������
		root_Left_VBox.setOnMousePressed((event) -> {
			x = event.getSceneX();
			y = event.getSceneY();
		});

		root_Left_VBox.setOnMouseDragged((event) -> {
			stage = (Stage) root.getScene().getWindow();
			stage.setX(event.getScreenX() - x);
			stage.setY(event.getScreenY() - y);
		});

		root_Left_VBox.setOnMouseReleased((event) -> {
			stage = (Stage) root.getScene().getWindow();
		});
	}
	
	private void stageMove2() {//https://ohtanja.tistory.com/90 ������
		root_center_HBox.setOnMousePressed((event) -> {
			x = event.getSceneX();
			y = event.getSceneY();
		});

		root_center_HBox.setOnMouseDragged((event) -> {
			stage = (Stage) root.getScene().getWindow();
			stage.setX(event.getScreenX() - x);
			stage.setY(event.getScreenY() - y);
		});

		root_center_HBox.setOnMouseReleased((event) -> {
			stage = (Stage) root.getScene().getWindow();
		});
	}
	
	private void hiddingButton() {
		hideb.setOnAction(event -> {stage = (Stage) root.getScene().getWindow(); stage.setIconified(true);});
	}
	
//	private void maxWindow() { //�ִ�ȭ
//		
//		maxb.setOnAction(event -> {
//			stage = (Stage) acp.getScene().getWindow();
//			stage.setMaximized(true);
//		});
//		
//	}
	
	public void changeFrame(ActionEvent e) {
		Button target = (Button)e.getSource();
		String data = target.getUserData().toString();
		System.out.println("[ListController] changeFrame() is started UserData: "+data);
		if(!nowView.equals(data)) {//���� ǥ�õ� ȭ��� ���� ������ 
			switch(data) {
			case"friend" :
				System.out.println("friend����");
				nowView = data;
				break;
			case"talk" :
				System.out.println("talk����");
				nowView = data;
				break;
			}
		}
	}
	
	public void openChat(ActionEvent e) throws IOException {
		System.out.println("[ListController] openChat() is Started");
		Stage newStage = new Stage();
		new ChatMain().start(newStage);

		
	}
	
	public void openVoiceChat(ActionEvent e) {
		System.out.println("[ListController] openVoiceChat() is Started");
	}

}
