package module;

public class User {
	
	private String id;
	private String pass;
	
	public User(String id, String pass) {
		this.id = id;
		this.pass = pass;
	}
	
	
}
