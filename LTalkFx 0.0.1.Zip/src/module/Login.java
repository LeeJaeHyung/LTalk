package module;

public class Login {
	
	public static void login(String id, String pass) {
		
	}
	
}
