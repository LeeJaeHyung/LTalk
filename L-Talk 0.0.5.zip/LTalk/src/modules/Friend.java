package modules;

import java.util.ArrayList;

public class Friend {

	ArrayList<String> friendList;

	public ArrayList<String> getFriendList() {
		return friendList;
	}

	public void setFriendList(ArrayList<String> friendList) {
		this.friendList = friendList;
	}
	
	public void  addFriend(String friend) {
		friendList.add(friend);
	}
	
	
}
