package controller;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import application.Main;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import modules.Chat;
import modules.Friend;
import modules.GsonLocalDateTimeAdapter;
import modules.Member;
import modules.Message;

public class LoginController implements Initializable {
	
	@FXML
	Button button;
	@FXML
	Button closeb;
	@FXML
	Button hideb;
	@FXML
	TextField id;
	@FXML
	PasswordField pass;
	@FXML
	AnchorPane acp;

	private double x = 0;
	private double y = 0;
	private Stage stage;
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

//		button.setOnAction(event -> System.out.println("람다로 실행됨"));

//		button.setOnAction(new EventHandler<ActionEvent>() {
//			@Override
//			public void handle(ActionEvent arg0) {
//				System.out.println("정석으로 이벤트 적용됨");
//				
//			}
//		});
//		bp.setBackground(new Background(new BackgroundFill(new Color(255, 235, 51, 0), null, null)));

		acp.setStyle("-fx-background-color:#FFEB33");
		closeb.setStyle("-fx-background-color:#FFEB33");
		hideb.setStyle("-fx-background-color:#FFEB33");
		button.setStyle("-fx-background-color:#F6F6F6");
		closeb.setOnAction(event -> Platform.exit());
		stageMove();
		hiddingButton();
		id.setOnAction(event -> {
			pass.requestFocus();
		});
		pass.setOnAction(event -> {
			try {
				requestLogin();
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("[MainController] initialize() in pass.setOnAction() is Exception ");
			}
		});
		

//		acp.setBackground(new Background(new BackgroundFill(new Color(255, 235, 51, 0), null, null)));

	}

	public void requestLoginSetButton(ActionEvent event) throws IOException {
		System.out.println(Thread.currentThread().getName()+" => [MainController] in requestLoginSetButton() => Login.login() 호출 di: ["+id.getText() + "] password: [ ****** ]");
//		Member member = Login.login(id.getText(), pass.getText());
		Member member = Main.database.requestLogin(id.getText(), pass.getText());
		Friend friend = Main.database.requestFriend(member.getId());
		member.setFriend(friend);
		if(member != null) {
			MainController.setMember(member);
			afterLogin(member);
			
		}
	}
	
	public void requestLogin() throws IOException {
		System.out.println(Thread.currentThread().getName()+" => [MainController] in requestLogin() => Login.login() 호출 di: ["+id.getText() + "] password: [ ****** ]");
//		Member member = Login.login(id.getText(), pass.getText());
		Member member = Main.database.requestLogin(id.getText(), pass.getText());
		if(member != null) {
			Friend friend = Main.database.requestFriend(member.getId());
			member.setFriend(friend);
			MainController.setMember(member);
			System.out.println("Member Loding clear");
			ArrayList<ArrayList<Message>> chatList = Main.database.requestMessgeList(friend.getFriendList(), id.getText());
			afterLogin(member);
		}
	}

	public void findId(MouseEvent event) {
		System.out.println("아이디 찾기 Event");
	}

	public void findPassword(MouseEvent event) {
		System.out.println("비밀번호 찾기 Event");
	}


	private void stageMove() {//https://ohtanja.tistory.com/90 참고함
		acp.setOnMousePressed((event) -> {
			x = event.getSceneX();
			y = event.getSceneY();
		});

		acp.setOnMouseDragged((event) -> {
			stage = (Stage) acp.getScene().getWindow();
			stage.setX(event.getScreenX() - x);
			stage.setY(event.getScreenY() - y);
		});

		acp.setOnMouseReleased((event) -> {
			stage = (Stage) acp.getScene().getWindow();
		});
	}
	
	
	public void afterLogin(Member member) throws IOException{
		System.out.println(Thread.currentThread().getName()+" => [MainController] afterLogin() is Started");
		Socket socket = new Socket();
		String IP = "localhost";
		int port = 7623;
		try {
			socket.connect(new InetSocketAddress(IP, port));
			Main.setServerOs(socket.getOutputStream());
			Main.setServerIs(socket.getInputStream());
			Gson gson = new Gson();
			String data = gson.toJson(member);
			byte[] buffer = data.getBytes();
			Main.serverOs.write(buffer);
			Main.serverOs.flush();
			Main.member = member;
			System.out.println("Send to Server -> MainController.member");
			receive();
		} catch (Exception e) {
			e.printStackTrace();
			if (!socket.isClosed()) {
				socket.close();
				System.out.println("[서버 접속 실패]");
			}
			return;
		}
		
		stage = (Stage)acp.getScene().getWindow();//  현제 스테이지 객체불러옴 
		stage.setUserData(member);
		Parent afterlogin = FXMLLoader.load(getClass().getResource("/view/Main.fxml"));
		Scene listScene = new Scene(afterlogin);
		stage.setScene(listScene);
		stage.setResizable(true);
		
//		Gson gson = new Gson();//GsonTest
//		Message message = new Message();
//		message.setSender("전송자");
//		message.setReceiver("수신자");
//		message.setText("내용");
//		System.out.println(gson.toJson(message));
//		Message messageTest = gson.fromJson(gson.toJson(message), Message.class);
//		System.out.println(messageTest.getSender()+" "+messageTest.getReceiver()+" "+message.getText());
		
		
		
		stage.show();
		Main.setServer(socket);
		MainController.setChat(new Chat());
		MainController.setStage(stage);
		
		
	}
	
	private void hiddingButton() {
		hideb.setOnAction(event -> {stage = (Stage) acp.getScene().getWindow(); stage.setIconified(true);});
	}
	
	public void receive() {
		Gson gson = new GsonBuilder().registerTypeAdapter(LocalDateTime.class, new GsonLocalDateTimeAdapter())
				.registerTypeAdapter(LocalDate.class, new GsonLocalDateTimeAdapter()).create();
		System.out.println("receive() is  start");
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				System.out.println(Thread.currentThread().getName() + " => receive()->run() is start");
				while (true) {
					byte[] buffer = new byte[1024];
					try {
						int bufferLength = Main.serverIs.read(buffer);
						if(bufferLength == -1 ) {
							System.out.println("LoginController.receive() -> 버퍼 length = -1");
							return;
						}
						String gsonData = new String(buffer, 0, bufferLength, "UTF-8");
						System.out.println("[reciveData] => " + gsonData);
						Message message = gson.fromJson(gsonData, Message.class);
						Main.chatList.get(message.getSender()).getControl().receiveMessage(message);
					} catch (NullPointerException e) {
						e.printStackTrace();
						break;
					} catch(SocketException e) {
						System.out.println("소켓이 닫혔습니다 -> LoginController.receive()가 break됩니다.");
						break;
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				System.out.println("receive 정상 처리 완료!");
			}

		};
		Main.threadPool.submit(runnable);
		System.out.println("ThreadPool.submit(receive())");
	}
}
