package controller;

import java.net.Socket;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import modules.Member;
import modules.Message;

public class ChatController implements Initializable {

//	public static Map<String ,ChatController> controllerList = new HashMap<String ,ChatController>();
	@FXML
	BorderPane root;
	@FXML
	HBox root_center_HBox;
	@FXML
	VBox root_Center_VBox;
	@FXML
	Button closeb;
	@FXML
	Button hideb;
	@FXML
	Button sendButton;
	@FXML
	TextArea textArea;
	@FXML
	VBox messageBox;
	@FXML
	ScrollPane scrollPane;
	@FXML
	Rectangle rectangle;
	@FXML
	Text receiverName;

	private Date lastDate;
	private String receiver;
	private String sender;
	private LocalDateTime beforDate;
	Member member;
	Socket socket;
	private boolean received = false;// 이전에 ScrollPane의 UI조작이 메세지수신인지 확인
	private boolean sent = false;// 이전에 ScrollPane의 UI조작이 메세지전송인지 확인
	private boolean last = false;// 삭제해야할 변수
	private boolean buttonChange = false; // 텍스트 에리어 옆의 전송버튼의 변화 상태 변수 false가 default
	private VBox lastRContent;// 이전에 받은 내용의 contentBox
	private HBox lastSContent;// 이전에 보낸 내용의 contentBox
	boolean textAreaFocus = false;
	private static String serverIP = "127.0.0.1"; // 로컬 주소
	private static int serverPort = 7623;
	private SimpleDateFormat timeFormat = new SimpleDateFormat("a KK:mm");
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("a KK:mm");
	Stage stage = null;
	private double x = 0, y = 0;

	ChangeListener<? super Boolean> eventScroll = (observable, oldValue, newValue) -> {
		if (!newValue) {
			scrollPane.setVvalue(1.0);
		}
	};

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			System.out.println(Thread.currentThread().getName() + " => [ChatController] initialize() is Strating");
			closeb.setStyle("-fx-background-color:#BACEE0");
			hideb.setStyle("-fx-background-color:#BACEE0");
			root_Center_VBox.setStyle("-fx-background-color:#BACEE0");
			root.setStyle("-fx-background-color:#BACEE0");
			// [현제 아래 버튼에 대한 이벤트 발생시 모든 프로그램이 종료됨 ] 해당 채팅방만 닫히는 기능구현이 필요함
			closeb.setOnAction(event -> closeStage());
			sendButton
					.setStyle("-fx-background-color: #F0F0F0;-fx-text-fill: #DADADA;-fx-font-family: 'Malgun Gothic';");
			messageBox.setPadding(new Insets(5));
			messageBox.setMaxHeight(Double.MAX_VALUE);
			messageBox.setPrefWidth(365.0);
			messageBox.setMaxWidth(365.0);
			scrollPane.setContent(messageBox);
			scrollPane.setHbarPolicy(ScrollBarPolicy.NEVER);
			scrollPane.setStyle(
					"-fx-background: transparent; -fx-background-color: transparent; -fx-border-color:#BACEE0;");
			Image im = new Image("file:src/images/lee.png");
			// ScrollPane의 max height를 무한대로 설정
			scrollPane.setMaxHeight(Double.MAX_VALUE);
			scrollPane.setFitToWidth(true);
			scrollPane.setFitToHeight(true);
			rectangle.setFill(new ImagePattern(im));
			stageMove();
			hiddingButton();
			sendButtonOnAction();
			sendTextAreaOnkey();
			scrollEvent();
			beforDate = LocalDateTime.now().minusDays(1);// 이부분은 파일이나 DB에서 채팅 내용을 불러올때 필요

			// 여기에 DB에 저장된 데이터를 가져오는 로직을 작성한다

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setTarget(String userName) {
		Platform.runLater(() -> {
			receiverName.setText(userName);
		});
	}

	private void scrollEvent() {
		scrollPane.needsLayoutProperty().addListener((observable, oldValue, newValue) -> {
			if (!newValue) {
				scrollPane.setVvalue(1.0);
			}
		});
	}

	private void hiddingButton() {
		hideb.setOnAction(event -> {
			stage = (Stage) root.getScene().getWindow();
			stage.setIconified(true);
		});
	}

	private void closeStage() {
		System.out.println("ChatController.closeStage() is Strat");
		try {
			stage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void stageMove() {// https://ohtanja.tistory.com/90 참고함
		root_center_HBox.setOnMousePressed((event) -> {
			x = event.getSceneX();
			y = event.getSceneY();
		});

		root_center_HBox.setOnMouseDragged((event) -> {
			stage = (Stage) root.getScene().getWindow();
			stage.setX(event.getScreenX() - x);
			stage.setY(event.getScreenY() - y);
		});

		root_center_HBox.setOnMouseReleased((event) -> {
			stage = (Stage) root.getScene().getWindow();
		});
	}

	public void sendTextAreaOnkey() {
		textArea.setOnKeyPressed((event) -> {
			if (event.getCode() == KeyCode.ENTER) {
				sendFunction();
			} else {
				if (event.getCode() == KeyCode.BACK_SPACE && textArea.getText().equals("")) {
					if (buttonChange) {
						buttonChange = false;
						sendButton.setStyle(
								"-fx-background-color: #F0F0F0;-fx-text-fill: #DADADA;-fx-font-family: 'Malgun Gothic';");
					}
				} else if (!buttonChange) {
					System.out.println(buttonChange);
					buttonChange = true;
					sendButton.setStyle(
							"-fx-background-color: #FFEB33;-fx-text-fill: #000000;-fx-font-family: 'Malgun Gothic';");
				}
			}
		});
	}

	// text 전달 메소드
	public void sendButtonOnAction() {
		sendButton.setOnAction((event) -> {
			if (buttonChange) {
				buttonChange = false;
				sendButton.setStyle(
						"-fx-background-color: #F0F0F0;-fx-text-fill: #DADADA;-fx-font-family: 'Malgun Gothic';");
			}
			sendFunction();
		});
	}

	public void sendFunction() {
		String text = textArea.getText();
		if (text.equals("\n") || text.equals("")) {
			textArea.setText("");
			return;
		}
		System.out.println("[ChatController] in sendFucntion Text : " + text);
		Message message = new Message();
		message.setReceiver(receiver);
		message.setSender(sender);
		message.setContent(text);
		message.setDate(LocalDateTime.now());
		MainController.getChat().send(message);
		System.out.println("message 송신 -> :" + message.getReceiver() + " " + message.getSender() + " "
				+ message.getContent() + " " + message.getDate());
		textArea.setText("");
		sendMessage(message);
		buttonChange = false;
		sendButton.setStyle(
				"-fx-background-color: #F0F0F0;-fx-text-fill: #DADADA;-fx-font-family: 'Malgun Gothic';");
		
	}

	public void moveScroll() {
		Platform.runLater(() -> {
			messageBox.layout();
			scrollPane.setVvalue(1.0d);
		});
	}

	public void receiveMessage(Message message) {
		System.out.println("receiveMessage() is success!");
		// messageArea.appendText(receiver+" : "+message);
		dateChecker();

		try {
			if (received) {// last --> received로 변경
				if (!timeChange(message.getDate())) { // timeChecker() --> timeChanger()로 변경, timeChecker() 삭제
					// timeChanger() 이전의 채팅 시간이 지금 가지고있는 시간과 동일한지 확인하는 용도
					// timeChecker false ==> 이전 채팅과 시간이 동일 true ==> 이전채팅과 시간이 다름
					// 이전에 찍힌 시간을 지우고 새로받은 채팅내용 뒤에 시간을 붇여야함
					Platform.runLater(() -> {
						int removeIndex = lastRContent.getChildren().size() - 1;
						((HBox) lastRContent.getChildren().get(removeIndex)).getChildren().remove(1);
					});
				}
				Platform.runLater(() -> {
					HBox contentBox = new HBox();
					Label content = new Label(message.getContent());
					content.setMaxSize(200, Double.MAX_VALUE);
					content.setMinHeight(Label.USE_PREF_SIZE);
					content.setWrapText(true);
					content.getStyleClass().add("chat");
					content.setStyle("-fx-background-color: #FFEB33;");
					Text time = new Text(message.getDate().format(formatter));
					time.setStyle("-fx-font-size: 10px; -fx-font-family: 'Malgun Gothic'; ");
					contentBox.setAlignment(Pos.BOTTOM_LEFT);
					contentBox.setMargin(time, new Insets(0, 0, 1, 5));
					contentBox.getChildren().addAll(content, time);
					lastRContent.getChildren().add(contentBox);
				});

			} else {
				beforDate = message.getDate();
				// 무조건 시간을 찍어야함
				Platform.runLater(() -> {
					Text sender = new Text(message.getSender());
					HBox recieveBox = new HBox();
					HBox contentBox = new HBox();
					VBox msgBox = new VBox();
					VBox chatBox = new VBox();
					chatBox.setSpacing(8);
					msgBox.setSpacing(2.5);
					Rectangle rec = new Rectangle(40, 40);
					rec.setArcHeight(25);
					rec.setArcWidth(25);
					Image im = new Image("file:src/images/lee.png");
					rec.setFill(new ImagePattern(im));
					recieveBox.setSpacing(8);
					Label content = new Label(message.getContent());
					content.setMaxSize(200, Double.MAX_VALUE);
					content.setMinHeight(Label.USE_PREF_SIZE);
					content.setWrapText(true);
					content.getStyleClass().add("chat");
					content.setStyle("-fx-background-color: #FFEB33;");
					recieveBox.setAlignment(Pos.TOP_LEFT);
					VBox.setMargin(recieveBox, new Insets(3.5));
					Text time = new Text(message.getDate().format(formatter));
					time.setStyle("-fx-font-size: 10px; -fx-font-family: 'Malgun Gothic'; ");
					contentBox.setAlignment(Pos.BOTTOM_LEFT);
					contentBox.setMargin(time, new Insets(0, 0, 1, 5));
					contentBox.getChildren().addAll(content, time);
					msgBox.getChildren().addAll(sender, chatBox);
					chatBox.getChildren().addAll(contentBox);
					recieveBox.getChildren().addAll(rec, msgBox);
					messageBox.getChildren().add(recieveBox);
					chatBox.needsLayoutProperty().addListener(eventScroll);
					if (lastRContent != null) {
						lastRContent.needsLayoutProperty().removeListener(eventScroll);
					}
					lastRContent = chatBox;
					received = true;
					sent = false;
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sendMessage(Message message) {// 시간 체크 로직 추가
		System.out.println("sendMessage");
		dateChecker();
		// 시간 체크
		if (sent) {// 직전에 ScrollPane의 변경된 UI가 메세지 전송인 경우 ==> true
			if (!timeChange(message.getDate())) { // 이전 전송시간과 동일 -> 이전 메세지의 시간을 지움
				// 이전 메세지의 시간을 지우는 로직을 추가함!
				System.out.println("시간이 같음 따라서 이전시간을 지웁니다!");
				lastSContent.getChildren().remove(0);
			} else {
				// 공백 추가
//				try {
//					Platform.runLater(() -> {
//						HBox space1 = new HBox();
//						space1.setPrefSize(0, 50);
//						space1.setStyle("-fx-background-color: red;");
//						messageBox.getChildren().add(space1);
//					});
//				} catch (Exception e) {
//					e.printStackTrace();
//					System.out.println("<timeChage == false>");
//				}

			}
		} else {
			beforDate = message.getDate();
			// 공백 추가

//			try {
//				Platform.runLater(() -> {
//					HBox space2 = new HBox();
//					space2.setPrefSize(0, 50);
//					space2.setStyle("-fx-background-color: red;");
//					messageBox.getChildren().add(space2);
//				});
//			} catch (Exception e) {
//				e.printStackTrace();
//				System.out.println("<sent == false>");
//			}
		}
		try {
			Platform.runLater(() -> {
				String fTime = message.getDate().format(formatter);
				System.out.println(fTime);
				Text time = new Text(fTime);
				time.setStyle("-fx-font-size: 10px; -fx-font-family: 'Malgun Gothic'; ");
				HBox timeBox = new HBox();
				timeBox.setMargin(time, new Insets(0, 5, 1, 0));
				timeBox.setAlignment(Pos.BOTTOM_RIGHT);
				timeBox.getChildren().add(time);
				HBox box = new HBox();
				Label msg = new Label(message.getContent());
				msg.setMaxSize(200, Double.MAX_VALUE);
				msg.setMinHeight(Label.USE_PREF_SIZE);
				msg.setWrapText(true);
				msg.getStyleClass().add("chat");
				box.getChildren().addAll(timeBox, msg);
				box.setAlignment(Pos.CENTER_RIGHT);
				VBox.setMargin(box, new Insets(3.5));
				messageBox.getChildren().add(box);
				lastSContent = timeBox;
			});
		} catch (Exception e) {
			e.printStackTrace();
		}

		sent = true;
		received = false;

	}

	public void dateChecker() {
		if (!(lastDate == null)) {
			Date nowDate = new Date();
			if (compareDate(lastDate, nowDate)) {
				return;
			} else {
				lastDate = nowDate;
				addPrintDate();
			}
		} else {
			lastDate = new Date();
			addPrintDate();
		}
	}

	public void addPrintDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("  yyyy년 MM월 dd일 E요일  ");
		Platform.runLater(() -> {
			VBox box = new VBox();
			Label dateT = new Label(sdf.format(lastDate));
			dateT.getStyleClass().add("chat");
			dateT.setStyle(
					"-fx-background-color: #B1C3D5; -fx-background-radius: 15px; -fx-effect:  dropshadow(three-pass-box , rgba(167,185,201,0.7) , 1, 0 , 1, 1);");
			box.setAlignment(Pos.CENTER);
			box.getChildren().add(dateT);
			box.setPadding(new Insets(5));
			messageBox.getChildren().add(box);
		});
	}

	public boolean compareDate(Date beforD, Date newD) {
		// y -> m -> d
		// y, m, d가 모두 같을경우 ->아무일도 일어 나지 않음
		if (beforD.getYear() == newD.getYear() && beforD.getMonth() == newD.getMonth()
				&& beforD.getDay() == newD.getDay()) {
			return true;
		}
		return false;
	}

	public boolean timeChange(LocalDateTime nowDate) {// 시간이 변경되었는 지 확인하는 용도
		if (beforDate.getHour() == nowDate.getHour() && beforDate.getMinute() == nowDate.getMinute()) {
			// 현재 시간과 이전 채팅의 시간이 동일할 때
			System.out.println(beforDate.format(formatter) + " " + nowDate.format(formatter) + " 시간이 같음");
			return false;
		} else {
			// 현재 시간과 이전 채팅의 시간이 다를 때
			System.out.println(beforDate.format(formatter) + " " + nowDate.format(formatter) + " 시간이 다름");
			beforDate = nowDate;
			return true;
		}
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

}
