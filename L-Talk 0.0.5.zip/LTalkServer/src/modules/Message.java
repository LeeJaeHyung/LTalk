package modules;

import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Message {

	@SerializedName("sender")
    @Expose
	private String sender;
	
	@SerializedName("receiver")
    @Expose
	private String receiver;
	
	@SerializedName("content")
    @Expose
	private String content;
	
	@SerializedName("date")
	@Expose
	private LocalDateTime date;
	
	@SerializedName("number")
	@Expose
	private int number;

	@SerializedName("checked")
	@Expose
	private boolean checked;
	
	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	
	
}
