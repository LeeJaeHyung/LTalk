package modules;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import application.Main;

public class Chat {

	public Socket socket;
	public OutputStream os;
	public InputStream is;
	public Member member;
	public DataBase dataBase = new DataBase();


	public Chat(Socket socket, Member member) {
		this.socket = socket;
		this.member = member;
		try {
			os = socket.getOutputStream();
			is = socket.getInputStream();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("getStream in Exception");
		}
	}

	public void send(Message message) {
		Gson gson = new GsonBuilder().registerTypeAdapter(LocalDateTime.class, new GsonLocalDateTimeAdapter())
				.registerTypeAdapter(LocalDate.class, new GsonLocalDateTimeAdapter()).create();
		if (Main.chats.containsKey(message.getReceiver())) {
			Runnable runnable = new Runnable() {
				@Override
				public void run() {
					try {
						byte[] buffer = gson.toJson(message).getBytes("UTF-8");
						os.write(buffer);
						os.flush();
						dataBase.MessageInsert(message);
						System.out.println("["+message.getSender()+" send to "+message.getReceiver()+"]: "+ message.getContent());
					} catch (Exception e) {
						try {
							System.out.println("[서버 메세지 송신 오류]" + socket.getRemoteSocketAddress() + ": "
									+ Thread.currentThread().getName());
							Main.chats.remove(member.getId());//해당 맴버와의 오류 때문에 해당멤버를 로그아웃 상태로 만듬
							if(socket!=null && !socket.isClosed()) {
								socket.close();
							}
							
							// 해당 리시버와연결이 부적절함으로 로그아웃상태로 판단 하여 처리 하였음  중이기에 여기에서 해당 리시버에 대하여 DB에 데이터를 쌓음
							
						
					
							
							
							
							
							
							
							
							
						} catch (Exception e2) {
							e2.printStackTrace();
						}
					}
				}
			};
			Main.threadPool.submit(runnable);
		}else {// 해당 수신자가 접속중이지 않음 -> DB에 데이터 저장
			System.out.println("해당 reciver가 서버에 존재 하지 않습니다");
		}
	}
	
	public synchronized void receive() {
		Gson gson = new GsonBuilder().registerTypeAdapter(LocalDateTime.class, new GsonLocalDateTimeAdapter())
				.registerTypeAdapter(LocalDate.class, new GsonLocalDateTimeAdapter()).create();
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				while(true) {
					byte[] buffer = new byte[1024];
					try {
						int bufferLength = is.read(buffer);
						String gsonData = new String(buffer, 0, bufferLength, "UTF-8");
						Message message = gson.fromJson(gsonData, Message.class);
						if(Main.chats.containsKey(message.getReceiver())) {
							Chat receiver = Main.chats.get(message.getReceiver());
							receiver.send(message);
							System.out.println("gsonData Send()!!"+gsonData);
						}else {
							System.out.println("해당 사용자가 없는데요?");
						}
					} catch (Exception e) {//Exception 발생시 해당 사용자에 대해 로그아웃 처리 따라서 소켓도 닫힘
						e.printStackTrace();
						System.out.println("Excepiton From! ->  Chat.receive ");
						System.out.println(member.getId()+"의 socket 닫힘!");
						Main.control.addText("[소켓 닫힘]"+member.getId()+"님이 로그아웃");
						Main.chats.remove(member.getId());//해당 맴버와의 오류 때문에 해당멤버를 로그아웃 상태로 만듬
						Main.control.addText("-------------------------------------");
						Main.control.addText("<현제 접속자>\n");
						Set<String>keySet = Main.chats.keySet();
						for(String user : keySet) {
							Main.control.addText(user+"\n");
						}
						Main.control.addText("-------------------------------------");
						if(socket!=null && !socket.isClosed()) {
							try {
								socket.close();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						break;
					}
				}
			}
		};

		Main.threadPool.submit(runnable);
	}
}
