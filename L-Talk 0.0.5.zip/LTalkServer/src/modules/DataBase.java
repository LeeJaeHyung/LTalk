package modules;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;

public class DataBase {

	private Connection conn = null;
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	DataBase() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521";
			String user = "L";
			String pass = "lee";
			conn = DriverManager.getConnection(url, user, pass);
			System.out.print(" 연결완료 Connection 객체 생성완료!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean MessageInsert(Message message) {
		try {
			String sql = "INSERT INTO MESSAGE (sender,receiver,message_content,message_date,message_number,message_checked) VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			//preparedStatment 를 이용하면 ?로 편하게 이용가능
			pstmt.setString(1, message.getSender());
			pstmt.setString(2, message.getReceiver());
			pstmt.setString(3, message.getContent());
			pstmt.setTimestamp(4, Timestamp.valueOf(message.getDate()));
			pstmt.setInt(5, 1);
			pstmt.setString(6, "Y");
			
			
			
			int rs = pstmt.executeUpdate();
			if(rs == 0) {
				System.out.println("실패");
			}else {
				System.out.println("성공");
			}
			conn.commit();
			pstmt.close();
	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}

	

}
