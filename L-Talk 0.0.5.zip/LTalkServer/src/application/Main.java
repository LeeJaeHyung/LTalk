package application;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.gson.Gson;

import controller.MainController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import modules.Chat;
import modules.Member;

public class Main extends Application {
	
	public static ExecutorService threadPool;
	static ServerSocket serverSocket;
	public static Map<String, Chat> chats = Collections.synchronizedMap(new HashMap<String, Chat>());
	public static MainController control;
	public static void main(String[] args) {
		launch();
	}
	

	@Override
	public void start(Stage primaryStage) throws Exception {// UI조작 공간
		System.out.println("["+Thread.currentThread().getName()+"] on start()");
		URL path = getClass().getResource("/view/ServerMain.fxml");
		FXMLLoader loader = new FXMLLoader(path);
		Parent parent = (Parent) loader.load();
		control = loader.getController();
		Scene scene = new Scene(parent);
		primaryStage.setScene(scene);
		primaryStage.setTitle("LTalk-Sever");
		primaryStage.getIcons().add(new Image("file:src/images/icon.png"));
		primaryStage.setResizable(false);
		primaryStage.setOnCloseRequest(event -> System.out.println("종료 됨"));// 닫기 버튼을 눌렀을때 발생하는 이벤트 stop 보다 먼저 실행됨
		primaryStage.show();
		
	}
	
	@Override
	public void stop() throws Exception {
		stopServer();
		super.stop();
	}
	
	@Override
	public void init() throws Exception {// 매개데이터 처리 작업 공간 UI 조작 불가
		
	}

	
	public static void startServer() {
		System.out.println("["+Thread.currentThread().getName()+"]: StratServer() is Start");
		threadPool = Executors.newFixedThreadPool(10);
		try {
			serverSocket = new ServerSocket();
			serverSocket.bind(new InetSocketAddress("localhost", 7623));
		} catch (Exception e) {
			System.out.println("ServerSocket -> is Exception");
			e.printStackTrace();
			if(!serverSocket.isClosed()) {
				stopServer();
			}
			return;
		}
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				while(true) {
					try {
						System.out.println("["+Thread.currentThread().getName()+"]: in running to accept()");
						Socket socket = serverSocket.accept();
						String text = "[연결수락: "+socket.getRemoteSocketAddress()+": "+Thread.currentThread().getName()+"]";
						System.out.println(text);
						InputStream is = socket.getInputStream();
						byte[] buffer = new byte[1024];
						int bufferLength = is.read(buffer);
						if(bufferLength == -1) {
							System.out.println("["+Thread.currentThread().getName()+"] <= data read Error");
						}
						String memberData = new String(buffer, 0, bufferLength, "UTF-8");
						System.out.println("Data => " + memberData);
						Gson gson = new Gson();
						Member member = gson.fromJson(memberData, Member.class);
						Chat chat =  new Chat(socket, member);
						chats.put(member.getId(), chat);
						chat.receive();
						System.out.println("[접속] "+member.getId()+"님이 접속하셨습니다.");
						control.addText(member.getId()+"님이 접속하셨습니다.\n");
						control.addText("-------------------------------------");
						control.addText("<현제 접속자>\n");
						Set<String>keySet = chats.keySet();
						for(String user : keySet) {
							control.addText(user+"\n");
						}
						control.addText("-------------------------------------");
						
					}catch(NullPointerException | IOException e) {
						System.out.println("run() -> is Exception");
						e.printStackTrace();
						if(serverSocket.isClosed()) {
							stopServer();
						}
						break;
					}
				}
			}
		};
		threadPool.submit(runnable);
	}
	public static void stopServer() {
		System.out.println("["+Thread.currentThread().getName()+"] :stopServer()");
		if(serverSocket!=null&&!serverSocket.isClosed()) {
			try {
				serverSocket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(threadPool!=null&&!threadPool.isShutdown()) {
			threadPool.shutdown();
		}
	}
	
	
}
