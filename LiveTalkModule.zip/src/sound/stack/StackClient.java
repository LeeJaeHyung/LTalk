package sound.stack;

import java.io.*;
import java.net.*;
import javax.sound.sampled.*;


public class StackClient {
	
	static AudioInputStream ais;
	static AudioFormat format;
	static int port = 52125;
	static float rate = 44100.0f;
	
	static DataLine.Info dataLineInfo;
	static SourceDataLine sourceDataLine;
	
	
	public static void main(String[] args){
		System.out.println("Client stated on port:"+port);
		System.setProperty("java.net.preferIPv4Stack", "true");
		try {
			
			InetAddress group = InetAddress.getByName("234.21.212.56");//��Ƽĳ��Ʈ �ּҸ� 
			MulticastSocket mSocket = new MulticastSocket(port);//������ ���ÿ� ��Ʈ�� ���ε�
			mSocket.joinGroup(group);//��Ƽĳ��Ʈ �׷쿡 ����
			
			byte[] reciveData = new byte[4096];// ���� �������� ũ��
			
			format = new AudioFormat(rate, 16, 2, true, false);
			
			dataLineInfo =  new DataLine.Info(SourceDataLine.class, format);
			sourceDataLine = (SourceDataLine) AudioSystem.getLine(dataLineInfo);
			sourceDataLine.open();
			sourceDataLine.start();
			
			DatagramPacket recivePacket = new DatagramPacket(reciveData, reciveData.length);
			ByteArrayInputStream baiss = new ByteArrayInputStream(recivePacket.getData());
			
			while (true) {
				mSocket.receive(recivePacket);
				ais = new AudioInputStream(baiss, format, recivePacket.getLength());
				toSpeaker(recivePacket.getData());
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void toSpeaker(byte soundbytes[]) {
		try {
			System.out.println("At Speaker");
			sourceDataLine.write(soundbytes, 0, soundbytes.length);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
