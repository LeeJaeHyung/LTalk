package modules;

import com.google.gson.Gson;

import application.Main;
import controller.ChatController;
import javafx.stage.Stage;

public class Chat {

	public Gson gson = new Gson();
	public Stage stage;
	public ChatController control;

	// 클라이언트 중지




	public void send(Message message) {

		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				try {
					byte[] buffer = gson.toJson(message).getBytes("UTF-8");
					Main.serverOs.write(buffer);
					Main.serverOs.flush();
				} catch (Exception e) {
					try {
						System.out.println("[메세지 송신 오류] : "
								+ Thread.currentThread().getName());
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}
			}

		};
		Main.threadPool.submit(runnable);
	}

	
	public void setStage(Stage s) {
		stage =s;
	}
	public Stage getStage() {
		return stage;
	}

	public ChatController getControl() {
		return control;
	}

	public void setControl(ChatController control) {
		this.control = control;
	}


}
